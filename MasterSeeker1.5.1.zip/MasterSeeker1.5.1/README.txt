If you're using Windows 2000/XP/2003 then .NET Framework 2.0 or newer is required to be installed to run MasterSeeker.
You can download .NET Framework 2.0 from the following links:
x86 version (32 bit): http://download.microsoft.com/download/c/6/e/c6e88215-0178-4c6c-b5f3-158ff77b1f38/NetFx20SP2_x86.exe
x64 version (64 bit): http://download.microsoft.com/download/c/6/e/c6e88215-0178-4c6c-b5f3-158ff77b1f38/NetFx20SP2_x64.exe
ia64 version: http://download.microsoft.com/download/c/6/e/c6e88215-0178-4c6c-b5f3-158ff77b1f38/NetFx20SP2_ia64.exe
